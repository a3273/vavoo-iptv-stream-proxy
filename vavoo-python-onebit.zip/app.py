import hashlib
import html
import os
import re
import threading
import time
import warnings
from typing import Generator, Optional
from urllib.parse import quote, urljoin, urlparse

import requests
from flask import Flask, Response, jsonify, request
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# This is a Python/Flask port of the uploaded Node.js project.
# Use it only with streams/services you are authorized to access.

warnings.simplefilter("ignore", InsecureRequestWarning)

app = Flask(__name__)

HTTP_HOST = os.getenv("HTTP_HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", "8000"))
CURRENT_LANGUAGE = os.getenv("VAVOO_LANGUAGE", "de")
CURRENT_REGION = os.getenv("VAVOO_REGION", "US")
VAVOO_URL_LIST = os.getenv("VAVOO_URL_LIST", "both").strip().lower()
REDIRECT = os.getenv("REDIRECT", "false").strip().lower() in {"1", "true", "yes", "on"}
CACHE_TTL = int(os.getenv("CACHE_TTL", "300"))
REQUEST_TIMEOUT = int(os.getenv("REQUEST_TIMEOUT", "30"))

if VAVOO_URL_LIST == "primary":
    BASE_SITES = ["https://vavoo.to"]
elif VAVOO_URL_LIST == "fallback":
    BASE_SITES = ["https://kool.to"]
else:
    BASE_SITES = ["https://vavoo.to", "https://kool.to"]

PING_URLS = ["https://www.vavoo.tv/api/app/ping"]
COUNTRY_SEPARATORS = ["➾", "⟾", "->", "→", "»", "›"]

_session = requests.Session()
_session.verify = False
_session.headers.update({"Connection": "close"})

_cache = {
    "signature": (None, 0.0),
    "channels": (None, 0.0),
}
_cache_lock = threading.Lock()


def _cache_get(key):
    value, expires = _cache[key]
    if value is not None and time.time() < expires:
        return value
    return None


def _cache_set(key, value, ttl=CACHE_TTL):
    _cache[key] = (value, time.time() + ttl)


def normalize(value) -> str:
    return str(value or "").strip().lower()


def normalize_channel_id_part(value) -> str:
    return re.sub(r"\s+", " ", normalize(value))


def get_stable_channel_id(name: str, country: str) -> str:
    seed = f"{normalize_channel_id_part(country)}|{normalize_channel_id_part(name)}"
    return hashlib.sha1(seed.encode("utf-8")).hexdigest()[:22]


def extract_country(group) -> str:
    raw = str(group or "").strip()
    if not raw:
        return "default"
    for separator in COUNTRY_SEPARATORS:
        if separator in raw:
            return raw.split(separator, 1)[0].strip() or "default"
    return raw


def get_catalog_headers(signature: str):
    return {
        "content-type": "application/json; charset=utf-8",
        "mediahubmx-signature": signature,
        "user-agent": "MediaHubMX/2",
        "accept": "*/*",
        "Accept-Language": CURRENT_LANGUAGE,
        "Accept-Encoding": "gzip, deflate",
        "Connection": "close",
    }


def get_stream_headers():
    headers = {"User-Agent": "VAVOO/2.6", "Connection": "close"}
    if request.headers.get("Range"):
        headers["Range"] = request.headers["Range"]
    return headers


def public_base_url() -> str:
    forwarded_proto = request.headers.get("X-Forwarded-Proto", "").split(",")[0].strip()
    scheme = forwarded_proto or request.scheme
    host = request.headers.get("X-Forwarded-Host", request.host)
    return f"{scheme}://{host}"


def proxied_upstream_url(upstream_url: str) -> str:
    return f"{public_base_url()}/hls-proxy?url={quote(upstream_url, safe='')}"


def playlist_response(body: str):
    response = Response(body, mimetype="application/vnd.apple.mpegurl")
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Pragma"] = "no-cache"
    return response


def is_m3u8_url(url: str) -> bool:
    try:
        return urlparse(url).path.lower().endswith(".m3u8")
    except Exception:
        return False


def is_m3u8_response(url: str, content_type: Optional[str]) -> bool:
    ct = str(content_type or "").lower()
    return "mpegurl" in ct or "application/vnd.apple" in ct or is_m3u8_url(url)


def should_rewrite_uri(uri: str) -> bool:
    trimmed = str(uri or "").strip()
    if not trimmed:
        return False
    return not re.match(r"^(data|urn|skd):", trimmed, re.I)


def rewrite_playlist_uri(base_url: str, uri: str) -> str:
    if not should_rewrite_uri(uri):
        return uri
    return proxied_upstream_url(urljoin(base_url, uri))


_URI_RE = re.compile(r'URI="([^"]+)"')


def rewrite_m3u8_playlist(upstream_url: str, playlist: str) -> str:
    out = []
    for line in str(playlist).splitlines():
        trimmed = line.strip()
        if not trimmed:
            out.append(line)
            continue
        if trimmed.startswith("#"):
            out.append(_URI_RE.sub(lambda m: f'URI="{rewrite_playlist_uri(upstream_url, m.group(1))}"', line))
        else:
            out.append(rewrite_playlist_uri(upstream_url, trimmed))
    return "\n".join(out)


def set_upstream_headers(response: Response, upstream: requests.Response):
    for key in ("Content-Type", "Content-Length", "Accept-Ranges", "Content-Range"):
        value = upstream.headers.get(key)
        if value:
            response.headers[key] = value


def ping_payload():
    now_ms = int(time.time() * 1000)
    return {
        "reason": "app-focus",
        "locale": CURRENT_LANGUAGE,
        "theme": "dark",
        "metadata": {
            "device": {"type": "desktop", "uniqueId": f"python-{now_ms}"},
            "os": {"name": "linux", "version": "Linux", "abis": ["x64"], "host": "python"},
            "app": {"platform": "electron"},
            "version": {"package": "tv.vavoo.app", "binary": "3.1.8", "js": "3.1.8"},
        },
        "appFocusTime": 0,
        "playerActive": False,
        "playDuration": 0,
        "devMode": False,
        "hasAddon": True,
        "castConnected": False,
        "package": "tv.vavoo.app",
        "version": "3.1.8",
        "process": "app",
        "firstAppStart": now_ms,
        "lastAppStart": now_ms,
        "ipLocation": None,
        "adblockEnabled": True,
        "proxy": {"supported": ["ss"], "engine": "Mu", "enabled": False, "autoServer": True},
        "iap": {"supported": False},
    }


def request_json(url: str, *, method="GET", headers=None, body=None, timeout=REQUEST_TIMEOUT):
    response = _session.request(method, url, headers=headers, json=body, timeout=timeout)
    try:
        data = response.json()
    except ValueError:
        data = None
    if not response.ok:
        raise RuntimeError(f"HTTP {response.status_code} for {url}")
    return data


def get_addon_signature() -> str:
    cached = _cache_get("signature")
    if cached:
        return cached

    payload = ping_payload()
    for url in PING_URLS:
        try:
            body = request_json(url, method="POST", body=payload)
            if isinstance(body, dict) and body.get("addonSig"):
                _cache_set("signature", body["addonSig"])
                return body["addonSig"]
        except Exception as exc:
            app.logger.warning("addonSig request failed for %s: %s", url, exc)

    raise RuntimeError("Unable to obtain addonSig")


def map_catalog_item(item):
    name = item.get("name") or "Unknown Channel"
    country = extract_country(item.get("group"))
    return {
        "id": get_stable_channel_id(name, country),
        "url": item.get("url"),
        "name": name,
        "logo": item.get("logo") or "",
        "group": item.get("group") or "",
        "country": country,
    }


def load_catalog_from_base(base_url: str, signature: str):
    catalog_url = base_url.rstrip("/") + "/mediahubmx-catalog.json"
    headers = get_catalog_headers(signature)
    channels = []
    cursor = None

    while True:
        body = request_json(
            catalog_url,
            method="POST",
            headers=headers,
            body={
                "language": CURRENT_LANGUAGE,
                "region": CURRENT_REGION,
                "catalogId": "iptv",
                "id": "iptv",
                "adult": False,
                "search": "",
                "sort": "",
                "filter": {},
                "cursor": cursor,
                "clientVersion": "3.0.2",
            },
        )
        items = body.get("items", []) if isinstance(body, dict) else []
        for item in items:
            if isinstance(item, dict) and item.get("type") == "iptv" and item.get("url"):
                channels.append(map_catalog_item(item))

        if not isinstance(body, dict) or not body.get("nextCursor"):
            break
        cursor = body["nextCursor"]

    return channels


def get_channels(force_refresh=False):
    if force_refresh:
        _cache["channels"] = (None, 0.0)

    cached = _cache_get("channels")
    if cached is not None:
        return cached

    # Avoid a stampede if several players request the playlist at once.
    with _cache_lock:
        cached = _cache_get("channels")
        if cached is not None:
            return cached
        signature = get_addon_signature()
        last_error = None
        for base_url in BASE_SITES:
            try:
                channels = load_catalog_from_base(base_url, signature)
                _cache_set("channels", channels)
                app.logger.info("channels loaded from %s: %s", base_url, len(channels))
                return channels
            except Exception as exc:
                last_error = exc
                app.logger.warning("catalog load failed for %s: %s", base_url, exc)
        raise RuntimeError(f"Unable to load channel catalog: {last_error}")


def get_channels_by_country(country: str):
    wanted = normalize(country)
    return [c for c in get_channels() if normalize(c["country"]) == wanted]


def get_countries():
    values = {
        c["country"] for c in get_channels()
        if c.get("country") and normalize(c["country"]) != "default"
    }
    return sorted(values, key=lambda x: x.lower())


def find_channel_by_id(channel_id: str):
    channel_id = str(channel_id or "").split("|", 1)[0]
    return next((c for c in get_channels() if str(c["id"]) == channel_id), None)


def resolve_stream_url(channel):
    signature = get_addon_signature()
    last_error = None
    for base_url in BASE_SITES:
        resolve_url = base_url.rstrip("/") + "/mediahubmx-resolve.json"
        try:
            body = request_json(
                resolve_url,
                method="POST",
                headers=get_catalog_headers(signature),
                body={
                    "language": CURRENT_LANGUAGE,
                    "region": CURRENT_REGION,
                    "url": channel["url"],
                    "clientVersion": "3.0.2",
                },
            )
            if isinstance(body, list) and body and isinstance(body[0], dict) and body[0].get("url"):
                return body[0]["url"]
            if isinstance(body, dict):
                if body.get("url"):
                    return body["url"]
                if body.get("streamUrl"):
                    return body["streamUrl"]
            raise RuntimeError("resolver returned no stream URL")
        except Exception as exc:
            last_error = exc
            app.logger.warning("resolve failed for %s: %s", base_url, exc)
    raise RuntimeError(f"Unable to resolve stream for channel {channel['name']}: {last_error}")


def stream_response(upstream: requests.Response):
    def generate() -> Generator[bytes, None, None]:
        try:
            for chunk in upstream.iter_content(chunk_size=64 * 1024):
                if chunk:
                    yield chunk
        finally:
            upstream.close()

    response = Response(generate(), status=upstream.status_code)
    set_upstream_headers(response, upstream)
    return response


def proxy_single_stream(stream_url: str, channel_name: str):
    try:
        upstream = _session.get(stream_url, headers=get_stream_headers(), stream=True, timeout=(REQUEST_TIMEOUT, None), allow_redirects=True)
        if not upstream.ok:
            raise RuntimeError(f"upstream returned HTTP {upstream.status_code}")

        content_type = upstream.headers.get("content-type")
        if is_m3u8_response(stream_url, content_type):
            playlist = upstream.text
            upstream.close()
            return playlist_response(rewrite_m3u8_playlist(stream_url, playlist))

        app.logger.info('starting stream proxy "%s"', channel_name)
        return stream_response(upstream)
    except Exception as exc:
        app.logger.warning('stream error "%s": %s', channel_name, exc)
        return Response(f"stream error: {exc}", status=400, mimetype="text/plain")


def proxy_upstream_url(upstream_url: str):
    parsed = urlparse(upstream_url)
    if parsed.scheme not in {"http", "https"}:
        return Response("unsupported upstream protocol", status=400)

    try:
        upstream = _session.get(upstream_url, headers=get_stream_headers(), stream=True, timeout=(REQUEST_TIMEOUT, None), allow_redirects=True)
        if not upstream.ok:
            raise RuntimeError(f"upstream returned HTTP {upstream.status_code}")

        content_type = upstream.headers.get("content-type")
        if is_m3u8_response(upstream_url, content_type):
            playlist = upstream.text
            upstream.close()
            return playlist_response(rewrite_m3u8_playlist(upstream_url, playlist))

        return stream_response(upstream)
    except Exception as exc:
        app.logger.warning("hls proxy error: %s", exc)
        return Response(f"upstream proxy error: {exc}", status=400, mimetype="text/plain")


@app.get("/")
def index():
    base = public_base_url()
    links = [
        ("M3U (all)", f"{base}/channels.m3u8"),
        ("M3U (Germany)", f"{base}/channels.m3u8?country=Germany"),
        ("M3U (Italy)", f"{base}/channels.m3u8?country=Italy"),
        ("M3U (France)", f"{base}/channels.m3u8?country=France"),
        ("M3U (Spain)", f"{base}/channels.m3u8?country=Spain"),
        ("M3U (United Kingdom)", f"{base}/channels.m3u8?country={quote('United Kingdom')}"),
        ("Countries", f"{base}/countries"),
    ]
    items = "\n".join(f'<li><a href="{html.escape(url)}">{html.escape(label)}</a></li>' for label, url in links)
    body = f"""<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><title>Vavoo Proxy</title><style>body{{font-family:sans-serif;background:#111;color:#f3f3f3;max-width:760px;margin:auto;padding:24px}}a{{color:#8fd3ff}}li{{margin:10px 0}}</style></head><body><h1>Vavoo Proxy</h1><p>Playlist and stream proxy endpoints.</p><ul>{items}</ul></body></html>"""
    return Response(body, mimetype="text/html")


@app.get("/countries")
def countries():
    try:
        return jsonify(get_countries())
    except Exception as exc:
        app.logger.warning("countries error: %s", exc)
        return Response(str(exc), status=500, mimetype="text/plain")


@app.get("/channels.m3u8")
def channels_m3u8():
    try:
        country = request.args.get("country")
        channels = get_channels_by_country(country) if country else get_channels()
        output = ["#EXTM3U"]
        base = public_base_url()
        for channel in channels:
            name = channel["name"].replace('"', "'")
            country_name = channel["country"].replace('"', "'")
            logo = channel["logo"].replace('"', "'")
            output.append(f'#EXTINF:-1 tvg-name="{name}" group-title="{country_name}" tvg-logo="{logo}" tvg-id="{name}",{name}')
            output.append("#EXTVLCOPT:http-user-agent=VAVOO/2.6")
            output.append("#EXTVLCOPT:no-ssl-verify")
            output.append(f"{base}/stream/{quote(channel['id'], safe='')}")
        return playlist_response("\n".join(output) + "\n")
    except Exception as exc:
        app.logger.warning("channels.m3u8 error: %s", exc)
        return Response(str(exc), status=500, mimetype="text/plain")


@app.get("/hls-proxy")
def hls_proxy():
    upstream_url = request.args.get("url")
    if not upstream_url:
        return Response("missing url", status=400)
    return proxy_upstream_url(upstream_url)


@app.get("/stream/<channel_id>")
def stream(channel_id: str):
    try:
        channel = find_channel_by_id(channel_id)
        if not channel:
            return Response(f"unknown channel: {channel_id}", status=404)

        stream_url = resolve_stream_url(channel)
        user_agent = request.headers.get("User-Agent", "").lower()

        if REDIRECT and "vavoo" in user_agent:
            return Response(status=302, headers={"Location": stream_url})

        if is_m3u8_url(stream_url):
            return playlist_response("#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-STREAM-INF:BANDWIDTH=8000000\n" + proxied_upstream_url(stream_url) + "\n")

        return proxy_single_stream(stream_url, channel["name"])
    except Exception as exc:
        app.logger.warning("playback error: %s", exc)
        return Response(str(exc), status=500, mimetype="text/plain")


if __name__ == "__main__":
    app.run(host=HTTP_HOST, port=PORT, threaded=True)
