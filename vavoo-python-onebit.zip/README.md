# Vavoo Proxy - Python / OneBit

Python/Flask port of the uploaded `vavoo-iptv-stream-proxy` project.

Use only with streams/services you are authorized to access.

## Files

- `app.py` - Flask application.
- `requirements.txt` - Python dependencies.
- `Procfile` - web start command for PaaS platforms.

## OneBit

Use a Python web service with:

- Root directory: `/`
- Python runtime: 3.12 (or a supported recent Python 3 version)
- Build/install: `pip install -r requirements.txt` if requested
- Start command: `gunicorn --bind 0.0.0.0:$PORT app:app`
- Do not add a Dockerfile.

Environment variables:

- `PORT` - supplied by the platform.
- `VAVOO_LANGUAGE` - default `de`.
- `VAVOO_REGION` - default `US`.
- `VAVOO_URL_LIST` - `primary`, `fallback`, or `both`; default `both`.
- `REDIRECT` - `true`/`false`; default `false`.
- `CACHE_TTL` - catalog/signature cache in seconds; default `300`.

## Endpoints

- `/`
- `/countries`
- `/channels.m3u8`
- `/channels.m3u8?country=Italy`
- `/stream/<id>`
- `/hls-proxy?url=<encoded-upstream-url>`
